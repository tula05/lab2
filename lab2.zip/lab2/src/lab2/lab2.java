package lab2;
import java.util.Scanner;  // Import the Scanner class
public class lab2 {

	private static Scanner sc;
    public static void main(String[] args) {
        int n, i;
          sc = new Scanner(System.in);
          System.out.print(" Please Enter your value : ");
          n = sc.nextInt();

          for(i = 1; i <= n; i++)
          {
              System.out.print(i);
              if (i % 5 == 0){
                  System.out.println();
              }else {
                  System.out.print(","+" ");
              }
          }
    }
}
    
