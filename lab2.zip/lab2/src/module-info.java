/**
 * 
 */
/**
 * @author Tul
 *
 */
module lab2 {
}